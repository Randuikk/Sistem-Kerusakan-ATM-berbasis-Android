package com.bri.atmpro;

public class RiwayatPekerjaan {

    private String id_riwayat;
    private String area;
    private String downtime;
    private String idatm;
    private String lokasi;
    private String keterangan;

    public RiwayatPekerjaan(String idr, String a, String d, String i, String l, String k) {
        id_riwayat = idr;
        area = a;
        downtime = d;
        idatm = i;
        lokasi = l;
        keterangan = k;
    }

    public String getId_riwayat() {
        return id_riwayat;
    }

    public void setId_riwayat(String id_riwayat) {
        this.id_riwayat = id_riwayat;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public String getDowntime() {
        return downtime;
    }

    public void setDowntime(String downtime) {
        this.downtime = downtime;
    }

    public String getIdatm() {
        return idatm;
    }

    public void setIdatm(String idatm) {
        this.idatm = idatm;
    }

    public String getLokasi() {
        return lokasi;
    }

    public void setLokasi(String lokasi) {
        this.lokasi = lokasi;
    }

    public String getKeterangan() {
        return keterangan;
    }

    public void setKeterangan(String keterangan) {
        this.keterangan = keterangan;
    }



}
