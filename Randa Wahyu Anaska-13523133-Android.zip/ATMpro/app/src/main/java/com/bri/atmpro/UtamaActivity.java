package com.bri.atmpro;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.messaging.FirebaseMessaging;

public class UtamaActivity extends AppCompatActivity {

    Button buttonUtamaATMproblem;
    Button buttonUtamaATMprogress;
    Button buttonutamaRiwayat;
    Button buttonUtamaSignOut;
    public static String id_teknisi = "";
    public static String vendor = "";
    public static String id_vendor = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_utama);

        buttonUtamaATMproblem = (Button)findViewById(R.id.buttonUtamaATMproblem);
        buttonUtamaATMprogress = (Button)findViewById(R.id.buttonUtamaATMprogress);
        buttonutamaRiwayat = (Button)findViewById(R.id.buttonutamaRiwayat);
        buttonUtamaSignOut = (Button)findViewById(R.id.buttonUtamaSignOut);

        buttonUtamaATMproblem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(UtamaActivity.this, ATMProblemActivity.class);
                startActivity(i);
            }
        });

        buttonUtamaATMprogress.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(UtamaActivity.this, ATMProgressActivity.class);
                startActivity(i);
            }
        });

        buttonutamaRiwayat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(UtamaActivity.this, RiwayatPekerjaanActivity.class);
                startActivity(i);
            }
        });

        buttonUtamaSignOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String vendor = UtamaActivity.vendor;
                FirebaseMessaging.getInstance().unsubscribeFromTopic(vendor);
                Toast.makeText(getApplicationContext(), "Unsubscribe from " +vendor , Toast.LENGTH_SHORT).show();

                Intent i = new Intent(UtamaActivity.this, LoginActivity.class);
                startActivity(i);
                finish();
            }
        });

        String vendor = UtamaActivity.vendor;
        //Toast.makeText(getApplicationContext(), vendor, Toast.LENGTH_LONG).show();
        try {
            FirebaseMessaging.getInstance().subscribeToTopic(vendor);
        } catch (Exception e) {
            Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_SHORT).show();
        }
        //Toast.makeText(getApplicationContext(), "Subscribe to "+vendor+", Token : " + FirebaseInstanceId.getInstance().getToken(), Toast.LENGTH_SHORT).show();
    }
}
