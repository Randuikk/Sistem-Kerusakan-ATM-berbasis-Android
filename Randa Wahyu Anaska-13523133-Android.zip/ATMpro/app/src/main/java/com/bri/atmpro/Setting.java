package com.bri.atmpro;

public class Setting {
    public static String url = "http://172.20.10.4/atmpro/";
}
