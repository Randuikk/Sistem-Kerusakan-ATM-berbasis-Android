package com.bri.atmpro;

public class ATMProblem {

    private String id_problem;
    private String area;
    private String downtime;
    private String idatm;
    private String lokasi;
    private String keterangan;

    public ATMProblem(String idp, String a, String d, String i, String l, String k) {
        id_problem = idp;
        area = a;
        downtime = d;
        idatm = i;
        lokasi = l;
        keterangan = k;
    }

    public String getId_problem() {
        return id_problem;
    }

    public void setId_problem(String id_problem) {
        this.id_problem = id_problem;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public String getDowntime() {
        return downtime;
    }

    public void setDowntime(String downtime) {
        this.downtime = downtime;
    }

    public String getIdatm() {
        return idatm;
    }

    public void setIdatm(String idatm) {
        this.idatm = idatm;
    }

    public String getLokasi() {
        return lokasi;
    }

    public void setLokasi(String lokasi) {
        this.lokasi = lokasi;
    }

    public String getKeterangan() {
        return keterangan;
    }

    public void setKeterangan(String keterangan) {
        this.keterangan = keterangan;
    }



}
