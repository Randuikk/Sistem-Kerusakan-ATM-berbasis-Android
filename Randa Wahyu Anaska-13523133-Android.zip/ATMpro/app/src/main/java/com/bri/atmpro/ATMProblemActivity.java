package com.bri.atmpro;

import android.app.ProgressDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class ATMProblemActivity extends AppCompatActivity {
//    String[] arridatm;
//    String[] arratmid;
//    String[] arratmip;
//    String[] arratmbrand;

    String[] arridproblem;
    String[] arrarea;
    String[] arrdowntime;
    String[] arratmid;
    String[] arrlokasi;
    String[] arrketerangan;
    //ListView listatmproblem;
    RecyclerView rvatmproblem;
    private JSONObject jObject;
    private String jsonResult ="";
    ProgressDialog pd;
    public static ATMProblemActivity obj;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_atmproblem);
        obj = this;
        getdata(UtamaActivity.id_vendor);
    }

    public void getdata(final String id_vendor) {

        StringRequest PostRequest = new StringRequest(Request.Method.POST, Setting.url + "getatmproblem.php?id_vendor="+id_vendor, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    //Toast.makeText(ATMProblemActivity.this, response, Toast.LENGTH_SHORT).show();
                    jObject = new JSONObject(response);
                    JSONArray menuitemArray = jObject
                            .getJSONArray("data");

                    arridproblem = new String[menuitemArray.length()];
                    arrarea = new String[menuitemArray.length()];
                    arrdowntime = new String[menuitemArray.length()];
                    arratmid = new String[menuitemArray.length()];
                    arrlokasi = new String[menuitemArray.length()];
                    arrketerangan = new String[menuitemArray.length()];
                    for (int i = 0; i < menuitemArray.length(); i++) {
                        arridproblem[i] = menuitemArray.getJSONObject(i).getString("id_problem").toString();
                        arrarea[i] = menuitemArray.getJSONObject(i).getString("area").toString();
                        arrdowntime[i] = menuitemArray.getJSONObject(i).getString("down_time").toString();
                        arratmid[i] = menuitemArray.getJSONObject(i).getString("atm_id").toString();
                        arrlokasi[i] = menuitemArray.getJSONObject(i).getString("lokasi").toString();
                        arrketerangan[i] = menuitemArray.getJSONObject(i).getString("keterangan").toString();
                    }

                } catch (JSONException e) {
                    // TODO Auto-generated catch block
                    Toast.makeText(getBaseContext(), "Gagal",
                            Toast.LENGTH_LONG).show();
                    e.printStackTrace();
                }

                //listatmproblem = (ListView)findViewById(R.id.listatmproblem);

                ArrayList<ATMProblem> itemList = new ArrayList<ATMProblem>();

                ATMProblemArrayAdapter itemArrayAdapter = new ATMProblemArrayAdapter(R.layout.row_atmproblem, itemList);
                rvatmproblem = (RecyclerView) findViewById(R.id.rvatmproblem);
                rvatmproblem.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
                rvatmproblem.setItemAnimator(new DefaultItemAnimator());
                rvatmproblem.setAdapter(itemArrayAdapter);

//                rvatmproblem.setOnClickListener(new View.OnClickListener() {
//                    @Override
//                    public void onClick(View view) {
//                        int itemPosition = rvatmproblem.getChildLayoutPosition(view);
//                        Toast.makeText(getApplicationContext(), String.valueOf(itemPosition), Toast.LENGTH_LONG).show();
//                    }
//                });

                // Populating list items
                for(int i=0; i<arridproblem.length; i++) {
                    //itemList.add(new Item("Item " + i));
                    itemList.add(new ATMProblem(arridproblem[i], arrarea[i], arrdowntime[i], arratmid[i], arrlokasi[i], arrketerangan[i]));
                }

                //listatmproblem.setAdapter(new ArrayAdapter(ATMProblemActivity.this, android.R.layout.simple_list_item_1, arratmip));
                //((ArrayAdapter)listatmproblem.getAdapter()).notifyDataSetInvalidated();

                pd.dismiss();
            }
        },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(ATMProblemActivity.this, "Error", Toast.LENGTH_SHORT).show();
                    }
                }
        ){
            protected Map<String, String> getParams(){
                Map<String, String> params = new HashMap<>();

                //params.put("username", User);
                //params.put("password", Pass);

                return params;
            }
        };
        pd = ProgressDialog.show(ATMProblemActivity.this, "Please Wait", "Connecting", true);
        pd.setCancelable(true);

        Volley.newRequestQueue(this).add(PostRequest);
    }

    public void set_problem(final String id_problem, final String id_teknisi) {

        StringRequest PostRequest = new StringRequest(Request.Method.POST, Setting.url + "set_problem.php", new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Toast.makeText(ATMProblemActivity.this, response + "Selamat Bekerja", Toast.LENGTH_SHORT).show();
                pd.dismiss();
                finish();

            }
        },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(ATMProblemActivity.this, "Error", Toast.LENGTH_SHORT).show();
                    }
                }
        ){
            protected Map<String, String> getParams(){
                Map<String, String> params = new HashMap<>();

                params.put("id_teknisi", id_teknisi);
                params.put("id_problem", id_problem);

                return params;
            }
        };
        pd = ProgressDialog.show(ATMProblemActivity.this, "Please Wait", "Connecting", true);
        pd.setCancelable(true);

        Volley.newRequestQueue(this).add(PostRequest);
    }
}
