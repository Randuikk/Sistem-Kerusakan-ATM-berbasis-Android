package com.bri.atmpro;

import android.app.ProgressDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class ATMProgressActivity extends AppCompatActivity {

    EditText editareaProgress;
    EditText editdown_timeProgress;
    EditText editatmidProgress;
    EditText editlokasiProgress;
    EditText editketeranganProgress;
    Button buttonSelesaiProgress;
    String[] arridproblem;
    String[] arrarea;
    String[] arrdowntime;
    String[] arratmid;
    String[] arrlokasi;
    String[] arrketerangan;
    String[] arridteknisi;
    //ListView listatmproblem;
    RecyclerView rvatmproblem;
    private JSONObject jObject;
    private String jsonResult ="";
    ProgressDialog pd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_atmprogress);

        editareaProgress = (EditText)findViewById(R.id.editareaProgress);
        editdown_timeProgress = (EditText)findViewById(R.id.editdown_timeProgress);
        editatmidProgress = (EditText)findViewById(R.id.editatmidProgress);
        editlokasiProgress = (EditText)findViewById(R.id.editlokasiProgress);
        editketeranganProgress = (EditText)findViewById(R.id.editketeranganProgress);
        buttonSelesaiProgress = (Button)findViewById(R.id.buttonSelesaiProgress);

        //editketeranganProgress.setText(getIntent().getStringExtra("keterangan"));

        buttonSelesaiProgress.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                insert_riwayat(arridproblem[0], "", editketeranganProgress.getText().toString());
            }
        });

        getdata(UtamaActivity.id_teknisi);
    }

    public void getdata(final String id_teknisi) {

        StringRequest PostRequest = new StringRequest(Request.Method.POST, Setting.url + "getatmprogress.php", new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    //Toast.makeText(ATMProgressActivity.this, response, Toast.LENGTH_SHORT).show();
                    jObject = new JSONObject(response);
                    JSONArray menuitemArray = jObject
                            .getJSONArray("data");

                    arridproblem = new String[menuitemArray.length()];
                    arrarea = new String[menuitemArray.length()];
                    arrdowntime = new String[menuitemArray.length()];
                    arratmid = new String[menuitemArray.length()];
                    arrlokasi = new String[menuitemArray.length()];
                    arrketerangan = new String[menuitemArray.length()];
                    arridteknisi = new String[menuitemArray.length()];
                    for (int i = 0; i < menuitemArray.length(); i++) {
                        arridproblem[i] = menuitemArray.getJSONObject(i).getString("id_problem").toString();
                        arrarea[i] = menuitemArray.getJSONObject(i).getString("area").toString();
                        arrdowntime[i] = menuitemArray.getJSONObject(i).getString("down_time").toString();
                        arratmid[i] = menuitemArray.getJSONObject(i).getString("atm_id").toString();
                        arrlokasi[i] = menuitemArray.getJSONObject(i).getString("lokasi").toString();
                        arrketerangan[i] = menuitemArray.getJSONObject(i).getString("keterangan").toString();
                        arridteknisi[i] = menuitemArray.getJSONObject(i).getString("id_teknisi").toString();
                    }

                } catch (JSONException e) {
                    // TODO Auto-generated catch block
                    Toast.makeText(getBaseContext(), "Gagal",
                            Toast.LENGTH_LONG).show();
                    e.printStackTrace();
                }

                //listatmproblem = (ListView)findViewById(R.id.listatmproblem);

                pd.dismiss();

                if (arridproblem.length > 0) {
                    editareaProgress.setText(arrarea[0]);
                    editdown_timeProgress.setText(arrdowntime[0]);
                    editatmidProgress.setText(arratmid[0]);
                    editlokasiProgress.setText(arrlokasi[0]);
                    editketeranganProgress.setText("");//arrketerangan[0]);
                } else {
                    finish();
                }
            }
        },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(ATMProgressActivity.this, "Error", Toast.LENGTH_SHORT).show();
                    }
                }
        ){
            protected Map<String, String> getParams(){
                Map<String, String> params = new HashMap<>();

                params.put("id_teknisi", id_teknisi);
                //params.put("password", Pass);

                return params;
            }
        };
        pd = ProgressDialog.show(ATMProgressActivity.this, "Please Wait", "Connecting", true);
        pd.setCancelable(true);

        Volley.newRequestQueue(this).add(PostRequest);
    }

    public void insert_riwayat(final String id_problem, final String up_time, final String keterangan) {

        StringRequest PostRequest = new StringRequest(Request.Method.POST, Setting.url + "insert_riwayat.php", new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Toast.makeText(ATMProgressActivity.this, response + "Berhasil", Toast.LENGTH_SHORT).show();
                pd.dismiss();
                finish();

            }
        },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(ATMProgressActivity.this, "Error", Toast.LENGTH_SHORT).show();
                    }
                }
        ){
            protected Map<String, String> getParams(){
                Map<String, String> params = new HashMap<>();

                params.put("id_problem", id_problem);
                params.put("up_time", up_time);
                params.put("keterangan", keterangan);

                return params;
            }
        };
        pd = ProgressDialog.show(ATMProgressActivity.this, "Please Wait", "Connecting", true);
        pd.setCancelable(true);

        Volley.newRequestQueue(this).add(PostRequest);
    }
}
