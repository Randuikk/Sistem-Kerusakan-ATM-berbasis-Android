package com.bri.atmpro;

import android.content.DialogInterface;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;

public class RiwayatPekerjaanArrayAdapter extends RecyclerView.Adapter<RiwayatPekerjaanArrayAdapter.ViewHolder> {

    //All methods in this adapter are required for a bare minimum recyclerview adapter
    private int listItemLayout;
    public static ArrayList<RiwayatPekerjaan> itemList;
    // Constructor of the class
    public RiwayatPekerjaanArrayAdapter(int layoutId, ArrayList<RiwayatPekerjaan> itemList) {
        listItemLayout = layoutId;
        this.itemList = itemList;
    }

    // get the size of the list
    @Override
    public int getItemCount() {
        return itemList == null ? 0 : itemList.size();
    }


    // specify the row layout file and click for each row
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(listItemLayout, parent, false);
        ViewHolder myViewHolder = new ViewHolder(view);
//        view.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
////                RecyclerView recyclerView = view.findViewById(R.id.rvriwayatpekerjaan);
////                int itemPosition = recyclerView.getChildLayoutPosition(view);
////                String item = itemList.get(itemPosition).getArea();
//                //Toast.makeText(view.getContext(), "ÖK" + itemList.get(item), Toast.LENGTH_LONG).show();
//            }
//        });
        return myViewHolder;
    }

    // load data in each row element
    @Override
    public void onBindViewHolder(final ViewHolder holder, final int listPosition) {
        TextView riwayatpekerjaan_area = holder.riwayatpekerjaan_area;
        TextView riwayatpekerjaan_down_time = holder.riwayatpekerjaan_down_time;
        TextView riwayatpekerjaan_id = holder.riwayatpekerjaan_id;
        TextView riwayatpekerjaan_lokasi = holder.riwayatpekerjaan_lokasi;
        riwayatpekerjaan_area.setText(itemList.get(listPosition).getArea());
        riwayatpekerjaan_down_time.setText(itemList.get(listPosition).getDowntime());
        riwayatpekerjaan_id.setText(itemList.get(listPosition).getIdatm());
        riwayatpekerjaan_lokasi.setText(itemList.get(listPosition).getLokasi());
    }

    // Static inner class to initialize the views of rows
    static class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        public TextView riwayatpekerjaan_area;
        public TextView riwayatpekerjaan_down_time;
        public TextView riwayatpekerjaan_id;
        public TextView riwayatpekerjaan_lokasi;
        public ViewHolder(View itemView) {
            super(itemView);
            itemView.setOnClickListener(this);
            riwayatpekerjaan_area = (TextView) itemView.findViewById(R.id.riwayatpekerjaan_area);
            riwayatpekerjaan_down_time = (TextView) itemView.findViewById(R.id.riwayatpekerjaan_down_time);
            riwayatpekerjaan_id = (TextView) itemView.findViewById(R.id.riwayatpekerjaan_id);
            riwayatpekerjaan_lokasi = (TextView) itemView.findViewById(R.id.riwayatpekerjaan_lokasi);
        }
        @Override
        public void onClick(final View view) {
            Log.d("onclick", "onClick " + getLayoutPosition() + " " + riwayatpekerjaan_area.getText());
            //Toast.makeText(, riwayatpekerjaan_area.getText(), Toast.LENGTH_LONG).show();
            //Intent i = new Intent(this, MainActivity.class);
            //startActivity(i);
//            Toast.makeText(view.getContext(), "ÖK " + getLayoutPosition() + " " + itemList.get(getLayoutPosition()).getArea(), Toast.LENGTH_LONG).show();
//
//            Intent i = new Intent(view.getContext(), ATMProgressActivity.class);
//            i.putExtra("id_problem", "");
//            i.putExtra("area", itemList.get(getLayoutPosition()).getArea());
//            i.putExtra("down_time", itemList.get(getLayoutPosition()).getDowntime());
//            i.putExtra("atm_id", itemList.get(getLayoutPosition()).getArea());
//            i.putExtra("lokasi", itemList.get(getLayoutPosition()).getLokasi());
//            i.putExtra("keterangan", itemList.get(getLayoutPosition()).getKeterangan());
//            view.getContext().startActivity(i);

//            AlertDialog.Builder builder = new AlertDialog.Builder(view.getContext());
//
//            builder.setTitle("Konfirmasi");
//            builder.setMessage("Apakah anda akan mengerjakan ATM ini?");
//
//            builder.setPositiveButton("Ya", new DialogInterface.OnClickListener() {
//
//                public void onClick(DialogInterface dialog, int which) {
//                    //Toast.makeText(view.getContext(), "id_problem="+itemList.get(getLayoutPosition()).getId_problem()+"posisi="+getLayoutPosition(), Toast.LENGTH_LONG).show();
//                    RiwayatPekerjaanActivity.obj.set_riwayat(itemList.get(getLayoutPosition()).getId_riwayat(), UtamaActivity.id_teknisi);
//                    // Do nothing, but close the dialog
//                    dialog.dismiss();
//                }
//            });
//
//            builder.setNegativeButton("Tidak", new DialogInterface.OnClickListener() {
//
//                @Override
//                public void onClick(DialogInterface dialog, int which) {
//
//                    // Do nothing
//                    dialog.dismiss();
//                }
//            });
//
//            AlertDialog alert = builder.create();
//            alert.show();
        }
    }


}

