package com.bri.atmpro;


import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;


public class ATMProblemArrayAdapter extends RecyclerView.Adapter<ATMProblemArrayAdapter.ViewHolder> {

    //All methods in this adapter are required for a bare minimum recyclerview adapter
    private int listItemLayout;
    public static ArrayList<ATMProblem> itemList;
    // Constructor of the class
    public ATMProblemArrayAdapter(int layoutId, ArrayList<ATMProblem> itemList) {
        listItemLayout = layoutId;
        this.itemList = itemList;
    }

    // get the size of the list
    @Override
    public int getItemCount() {
        return itemList == null ? 0 : itemList.size();
    }


    // specify the row layout file and click for each row
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(listItemLayout, parent, false);
        ViewHolder myViewHolder = new ViewHolder(view);
//        view.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
////                RecyclerView recyclerView = view.findViewById(R.id.rvatmproblem);
////                int itemPosition = recyclerView.getChildLayoutPosition(view);
////                String item = itemList.get(itemPosition).getArea();
//                //Toast.makeText(view.getContext(), "ÖK" + itemList.get(item), Toast.LENGTH_LONG).show();
//            }
//        });
        return myViewHolder;
    }

    // load data in each row element
    @Override
    public void onBindViewHolder(final ViewHolder holder, final int listPosition) {
        TextView atmproblem_area = holder.atmproblem_area;
        TextView atmproblem_down_time = holder.atmproblem_down_time;
        TextView atmproblem_id = holder.atmproblem_id;
        TextView atmproblem_lokasi = holder.atmproblem_lokasi;
        atmproblem_area.setText(itemList.get(listPosition).getArea());
        atmproblem_down_time.setText(itemList.get(listPosition).getDowntime());
        atmproblem_id.setText(itemList.get(listPosition).getIdatm());
        atmproblem_lokasi.setText(itemList.get(listPosition).getLokasi());
    }

    // Static inner class to initialize the views of rows
    static class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        public TextView atmproblem_area;
        public TextView atmproblem_down_time;
        public TextView atmproblem_id;
        public TextView atmproblem_lokasi;
        public ViewHolder(View itemView) {
            super(itemView);
            itemView.setOnClickListener(this);
            atmproblem_area = (TextView) itemView.findViewById(R.id.atmproblem_area);
            atmproblem_down_time = (TextView) itemView.findViewById(R.id.atmproblem_down_time);
            atmproblem_id = (TextView) itemView.findViewById(R.id.atmproblem_id);
            atmproblem_lokasi = (TextView) itemView.findViewById(R.id.atmproblem_lokasi);
        }
        @Override
        public void onClick(final View view) {
            Log.d("onclick", "onClick " + getLayoutPosition() + " " + atmproblem_area.getText());
            //Toast.makeText(, atmproblem_area.getText(), Toast.LENGTH_LONG).show();
            //Intent i = new Intent(this, MainActivity.class);
            //startActivity(i);
//            Toast.makeText(view.getContext(), "ÖK " + getLayoutPosition() + " " + itemList.get(getLayoutPosition()).getArea(), Toast.LENGTH_LONG).show();
//
//            Intent i = new Intent(view.getContext(), ATMProgressActivity.class);
//            i.putExtra("id_problem", "");
//            i.putExtra("area", itemList.get(getLayoutPosition()).getArea());
//            i.putExtra("down_time", itemList.get(getLayoutPosition()).getDowntime());
//            i.putExtra("atm_id", itemList.get(getLayoutPosition()).getArea());
//            i.putExtra("lokasi", itemList.get(getLayoutPosition()).getLokasi());
//            i.putExtra("keterangan", itemList.get(getLayoutPosition()).getKeterangan());
//            view.getContext().startActivity(i);

            AlertDialog.Builder builder = new AlertDialog.Builder(view.getContext());

            builder.setTitle("Konfirmasi");
            builder.setMessage("Apakah anda akan mengerjakan ATM ini?");

            builder.setPositiveButton("Ya", new DialogInterface.OnClickListener() {

                public void onClick(DialogInterface dialog, int which) {
                    //Toast.makeText(view.getContext(), "id_problem="+itemList.get(getLayoutPosition()).getId_problem()+"posisi="+getLayoutPosition(), Toast.LENGTH_LONG).show();
                    ATMProblemActivity.obj.set_problem(itemList.get(getLayoutPosition()).getId_problem(), UtamaActivity.id_teknisi);
                    // Do nothing, but close the dialog
                    dialog.dismiss();
                }
            });

            builder.setNegativeButton("Tidak", new DialogInterface.OnClickListener() {

                @Override
                public void onClick(DialogInterface dialog, int which) {

                    // Do nothing
                    dialog.dismiss();
                }
            });

            AlertDialog alert = builder.create();
            alert.show();
        }
    }


}
