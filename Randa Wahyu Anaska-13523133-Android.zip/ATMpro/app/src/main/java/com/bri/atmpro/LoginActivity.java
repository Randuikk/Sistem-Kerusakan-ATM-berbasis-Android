package com.bri.atmpro;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.firebase.messaging.FirebaseMessaging;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class LoginActivity extends AppCompatActivity {

    EditText editusername_Login;
    EditText editpassword_Login;
    Button button_Login;
    Button buttonSignUp_Login;

    private JSONObject jObject;
    private String jsonResult ="";
    ProgressDialog pd;

//    private static final String PREF_SWITCH_NEWS = "switch_news";
//    private static final String PREF_SWITCH_PROMO = "switch_promo";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //this.requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_login);

        editusername_Login = (EditText)findViewById(R.id.editusername_Login);
        editpassword_Login = (EditText)findViewById(R.id.editpassword_Login);
        button_Login = (Button)findViewById(R.id.buttonLogin_Login);
        buttonSignUp_Login = (Button)findViewById(R.id.buttonSignUp_Login);

        button_Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                cekdata(editusername_Login.getText().toString(), editpassword_Login.getText().toString());
            }
        });

        buttonSignUp_Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(LoginActivity.this, SignUpActivity.class);
                startActivity(i);
            }
        });

//        FirebaseMessaging.getInstance().subscribeToTopic("news");
//        Toast.makeText(getApplicationContext(), "Subscribe to News Topic" , Toast.LENGTH_SHORT).show();
//
//        FirebaseMessaging.getInstance().subscribeToTopic("promo");
//        Toast.makeText(getApplicationContext(), "Subscribe to Promo Topic", Toast.LENGTH_SHORT).show();
    }

    public void cekdata(final String username, final String password) {

        StringRequest PostRequest = new StringRequest(Request.Method.POST, Setting.url + "cekteknisi.php", new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    //Toast.makeText(LoginActivity.this, response, Toast.LENGTH_SHORT).show();
                    jObject = new JSONObject(response);
                    JSONArray menuitemArray = jObject
                            .getJSONArray("data");

                    if (menuitemArray.length()>0) {
                        //arridatm[i] = menuitemArray.getJSONObject(i).getString("id_atm").toString();
                        UtamaActivity.id_teknisi = menuitemArray.getJSONObject(0).getString("id_teknisi").toString();
                        UtamaActivity.vendor = menuitemArray.getJSONObject(0).getString("vendor").toString();
                        UtamaActivity.id_vendor = menuitemArray.getJSONObject(0).getString("id_vendor").toString();

                        Intent i = new Intent(LoginActivity.this, UtamaActivity.class);
                        startActivity(i);

                        //Toast.makeText(LoginActivity.this, UtamaActivity.id_teknisi, Toast.LENGTH_SHORT).show();
                        pd.dismiss();
                        finish();
                    } else {
                        pd.dismiss();
                        Toast.makeText(getBaseContext(), "Login Gagal",
                                Toast.LENGTH_LONG).show();

                    }

                } catch (JSONException e) {
                    // TODO Auto-generated catch block
                    Toast.makeText(getBaseContext(), "Gagal",
                            Toast.LENGTH_LONG).show();
                    e.printStackTrace();
                    pd.dismiss();
                }



            }
        },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(LoginActivity.this, "Error", Toast.LENGTH_SHORT).show();
                    }
                }
        ){
            protected Map<String, String> getParams(){
                Map<String, String> params = new HashMap<>();

                params.put("username", username);
                params.put("password", password);

                return params;
            }
        };
        pd = ProgressDialog.show(LoginActivity.this, "Please Wait", "Connecting", true);
        pd.setCancelable(true);

        Volley.newRequestQueue(this).add(PostRequest);
    }
}
