package com.bri.atmpro;

import android.app.ProgressDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class RiwayatPekerjaanActivity extends AppCompatActivity {
//    String[] arridatm;
//    String[] arratmid;
//    String[] arratmip;
//    String[] arratmbrand;

    String[] arridriwayat;
    String[] arrarea;
    String[] arrdowntime;
    String[] arratmid;
    String[] arrlokasi;
    String[] arrketerangan;
    //ListView listriwayatpekerjaan;
    RecyclerView rvriwayatpekerjaan;
    private JSONObject jObject;
    private String jsonResult ="";
    ProgressDialog pd;
    public static RiwayatPekerjaanActivity obj;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_riwayat_pekerjaan);
        obj = this;
        getdata(UtamaActivity.id_teknisi);
    }

    public void getdata(final String id_teknisi) {

        // Toast.makeText(getApplicationContext(), Setting.url + "getriwayatpekerjaan.php?id_teknisi="+id_teknisi, Toast.LENGTH_LONG).show();
        StringRequest PostRequest = new StringRequest(Request.Method.POST, Setting.url + "getriwayatpekerjaan.php?id_teknisi="+id_teknisi, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    //Toast.makeText(RiwayatPekerjaanActivity.this, response, Toast.LENGTH_SHORT).show();
                    jObject = new JSONObject(response);
                    JSONArray menuitemArray = jObject
                            .getJSONArray("data");

                    arridriwayat = new String[menuitemArray.length()];
                    arrarea = new String[menuitemArray.length()];
                    arrdowntime = new String[menuitemArray.length()];
                    arratmid = new String[menuitemArray.length()];
                    arrlokasi = new String[menuitemArray.length()];
                    arrketerangan = new String[menuitemArray.length()];
                    for (int i = 0; i < menuitemArray.length(); i++) {
                        arridriwayat[i] = menuitemArray.getJSONObject(i).getString("id_riwayat").toString();
                        arrarea[i] = menuitemArray.getJSONObject(i).getString("area").toString();
                        arrdowntime[i] = menuitemArray.getJSONObject(i).getString("down_time").toString();
                        arratmid[i] = menuitemArray.getJSONObject(i).getString("atm_id").toString();
                        arrlokasi[i] = menuitemArray.getJSONObject(i).getString("lokasi").toString();
                        arrketerangan[i] = menuitemArray.getJSONObject(i).getString("keterangan").toString();
                    }

                } catch (JSONException e) {
                    // TODO Auto-generated catch block
                    Toast.makeText(getBaseContext(), "Gagal",
                            Toast.LENGTH_LONG).show();
                    e.printStackTrace();
                }

                //listriwayatpekerjaan = (ListView)findViewById(R.id.listriwayatpekerjaan);

                ArrayList<RiwayatPekerjaan> itemList = new ArrayList<RiwayatPekerjaan>();

                RiwayatPekerjaanArrayAdapter itemArrayAdapter = new RiwayatPekerjaanArrayAdapter(R.layout.row_riwayatpekerjaan, itemList);
                rvriwayatpekerjaan = (RecyclerView) findViewById(R.id.rvriwayatpekerjaan);
                rvriwayatpekerjaan.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
                rvriwayatpekerjaan.setItemAnimator(new DefaultItemAnimator());
                rvriwayatpekerjaan.setAdapter(itemArrayAdapter);

//                rvriwayatpekerjaan.setOnClickListener(new View.OnClickListener() {
//                    @Override
//                    public void onClick(View view) {
//                        int itemPosition = rvriwayatpekerjaan.getChildLayoutPosition(view);
//                        Toast.makeText(getApplicationContext(), String.valueOf(itemPosition), Toast.LENGTH_LONG).show();
//                    }
//                });

                // Populating list items
                for(int i=0; i<arridriwayat.length; i++) {
                    //itemList.add(new Item("Item " + i));
                    itemList.add(new RiwayatPekerjaan(arridriwayat[i], arrarea[i], arrdowntime[i], arratmid[i], arrlokasi[i], arrketerangan[i]));
                }

                //listriwayatpekerjaan.setAdapter(new ArrayAdapter(ATMProblemActivity.this, android.R.layout.simple_list_item_1, arratmip));
                //((ArrayAdapter)listriwayatpekerjaan.getAdapter()).notifyDataSetInvalidated();

                pd.dismiss();
            }
        },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(RiwayatPekerjaanActivity.this, "Error", Toast.LENGTH_SHORT).show();
                    }
                }
        ){
            protected Map<String, String> getParams(){
                Map<String, String> params = new HashMap<>();

                params.put("id_teknisi", id_teknisi);
                //params.put("password", Pass);

                return params;
            }
        };
        pd = ProgressDialog.show(RiwayatPekerjaanActivity.this, "Please Wait", "Connecting", true);
        pd.setCancelable(true);

        Volley.newRequestQueue(this).add(PostRequest);
    }

    public void set_riwayat(final String id_riwayat, final String id_teknisi) {

        StringRequest PostRequest = new StringRequest(Request.Method.POST, Setting.url + "set_riwayat.php", new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Toast.makeText(RiwayatPekerjaanActivity.this, response + "Selamat Bekerja", Toast.LENGTH_SHORT).show();
                pd.dismiss();
                finish();

            }
        },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(RiwayatPekerjaanActivity.this, "Error", Toast.LENGTH_SHORT).show();
                    }
                }
        ){
            protected Map<String, String> getParams(){
                Map<String, String> params = new HashMap<>();

                params.put("id_teknisi", id_teknisi);
                params.put("id_riwayat", id_riwayat);

                return params;
            }
        };
        pd = ProgressDialog.show(RiwayatPekerjaanActivity.this, "Please Wait", "Connecting", true);
        pd.setCancelable(true);

        Volley.newRequestQueue(this).add(PostRequest);
    }
}
