package com.bri.atmpro;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class SignUpActivity extends AppCompatActivity {

    EditText editnamalengkap_signup;
    EditText editTextphone_SignUp;
    EditText editusername_signup;
    EditText editpassword_SignUp;
    Spinner spinnerVendor_SignUp;
    Button buttonSignUp_SignUp;

    private JSONObject jObject;
    private String jsonResult ="";
    ProgressDialog pd;

    String[] arridvendor;
    String[] arrvendor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        editnamalengkap_signup = (EditText)findViewById(R.id.editnamalengkap_signup);
        editTextphone_SignUp = (EditText)findViewById(R.id.editTextphone_SignUp);
        editusername_signup = (EditText)findViewById(R.id.editusername_signup);
        editpassword_SignUp = (EditText)findViewById(R.id.editpassword_SignUp);
        spinnerVendor_SignUp = (Spinner) findViewById(R.id.spinnerVendor_SignUp);
        buttonSignUp_SignUp = (Button)findViewById(R.id.buttonSignUp_SignUp);

        buttonSignUp_SignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), editTextphone_SignUp.getText().toString() + " " +
                        editpassword_SignUp.getText().toString(), Toast.LENGTH_LONG).show();
                register(
                        editnamalengkap_signup.getText().toString(),
                        editTextphone_SignUp.getText().toString(),
                        editusername_signup.getText().toString(),
                        editpassword_SignUp.getText().toString(),
                        arridvendor[spinnerVendor_SignUp.getSelectedItemPosition()]
                );
            }
        });

        getdata();
    }

    public void register(final String namalengkap, final String phone, final String username, final String password, final String vendor) {

        StringRequest PostRequest = new StringRequest(Request.Method.POST, Setting.url + "signup_teknisi.php", new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Toast.makeText(SignUpActivity.this, response + "Berhasil", Toast.LENGTH_SHORT).show();
                pd.dismiss();
                finish();

            }
        },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(SignUpActivity.this, "Error", Toast.LENGTH_SHORT).show();
                    }
                }
        ){
            protected Map<String, String> getParams(){
                Map<String, String> params = new HashMap<>();

                params.put("nama_lengkap", namalengkap);
                params.put("nomor_handphone", phone);
                params.put("username", username);
                params.put("password", password);
                params.put("id_vendor", vendor);

                return params;
            }
        };
        pd = ProgressDialog.show(SignUpActivity.this, "Please Wait", "Connecting", true);
        pd.setCancelable(true);

        Volley.newRequestQueue(this).add(PostRequest);
    }

    public void getdata() {

        StringRequest PostRequest = new StringRequest(Request.Method.POST, Setting.url + "getvendor.php", new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    //Toast.makeText(SignUpActivity.this, response, Toast.LENGTH_SHORT).show();
                    jObject = new JSONObject(response);
                    JSONArray menuitemArray = jObject
                            .getJSONArray("data");

                    arridvendor = new String[menuitemArray.length()];
                    arrvendor = new String[menuitemArray.length()];

                    for (int i = 0; i < menuitemArray.length(); i++) {
                        arridvendor[i] = menuitemArray.getJSONObject(i).getString("id_vendor").toString();
                        arrvendor[i] = menuitemArray.getJSONObject(i).getString("vendor").toString();

                    }

                } catch (JSONException e) {
                    // TODO Auto-generated catch block
                    Toast.makeText(getBaseContext(), "Gagal",
                            Toast.LENGTH_LONG).show();
                    e.printStackTrace();
                }

                ArrayAdapter<String> adapter;

                adapter =  new ArrayAdapter<String>(SignUpActivity.this, android.R.layout.simple_spinner_item, arrvendor);

                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

                spinnerVendor_SignUp.setAdapter(adapter);

                pd.dismiss();
            }
        },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(SignUpActivity.this, "Error", Toast.LENGTH_SHORT).show();
                    }
                }
        ){
            protected Map<String, String> getParams(){
                Map<String, String> params = new HashMap<>();

                //params.put("username", User);
                //params.put("password", Pass);

                return params;
            }
        };
        pd = ProgressDialog.show(SignUpActivity.this, "Please Wait", "Connecting", true);
        pd.setCancelable(true);

        Volley.newRequestQueue(this).add(PostRequest);
    }
}
